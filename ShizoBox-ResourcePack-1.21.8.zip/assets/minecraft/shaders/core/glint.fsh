#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 glint = texture(Sampler0, texCoord0);
    float phase = texCoord0.x * 0.35 + texCoord0.y * 0.20 + GameTime * 120.0;
    vec3 spectrum = 0.70 + 0.30 * cos(6.2831853 * (phase + vec3(0.0, -0.3333333, 0.3333333)));
    float pattern = max(glint.r, max(glint.g, glint.b));
    float strength = max(ColorModulator.r, max(ColorModulator.g, ColorModulator.b));
    vec4 color = vec4(spectrum * pattern * strength, glint.a * ColorModulator.a);
    if (color.a < 0.1) {
        discard;
    }
    float fade = (1.0f - total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd)) * GlintAlpha;
    fragColor = vec4(color.rgb * fade, color.a);
}
