# ShizoBox equipment and coins

Original project pixel art and native Minecraft item models, created on 2026-09-16.
The source generator is development/economy-redesign-work/make_assets.py in the server workspace.
No external image, photograph, game texture or generated API image was used as input for these new assets.
Animation is drawn in item texture frames. Worn armor textures are static.
Existing unrelated resource-pack assets and their source/licensing notices are retained unchanged.
