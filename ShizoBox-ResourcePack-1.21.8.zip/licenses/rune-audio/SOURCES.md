# Rune audio v1 — происхождение до генерации

Дата: 2026-09-16. Все восемь WAV и соответствующие OGG создаются с нуля
скриптом [make_rune_audio.py](make_rune_audio.py). Автор генератора: Codex для
проекта ShizoBox. Источник аудио: математические осцилляторы, огибающие,
детерминированный шум NumPy; входных записей и внешних сэмплов нет.
Minecraft, Warden v6 и пользовательская glitch-компиляция не используются.

Новые результаты процедурного синтеза и этот генератор предоставляются
под CC0 1.0 Universal в той мере, в которой в них возникают охраняемые права.
Это не переоформление лицензии существующих ассетов проекта.
Условия проверены по [официальному описанию CC0](https://creativecommons.org/publicdomain/zero/1.0/)
и доступны в [полном тексте](https://creativecommons.org/publicdomain/zero/1.0/legalcode):
копирование, изменение и распространение, включая коммерческое, без обязательной
атрибуции; без гарантий; чужие права на товарные знаки/патенты не предоставляются.
Сторонних звуковых источников, требующих отдельной лицензии, нет.

| Файлы (WAV + OGG) | Точный источник | Автор | Лицензия | Синтез |
|---|---|---|---|---|
| winter_activate | make_rune_audio.py / winter / seed 610 | Codex для ShizoBox | CC0-1.0 | ледяной ветер, негармонические кристаллы, треск |
| winter_impact | make_rune_audio.py / winter / seed 611 | Codex для ShizoBox | CC0-1.0 | короткий раскол льда |
| demon_activate | make_rune_audio.py / demon / seed 620 | Codex для ShizoBox | CC0-1.0 | формантный рык, пламя, низкий удар |
| demon_impact | make_rune_audio.py / demon / seed 621 | Codex для ShizoBox | CC0-1.0 | огненный выброс и басовый рык |
| dark_activate | make_rune_audio.py / dark / seed 630 | Codex для ShizoBox | CC0-1.0 | дрейфующий дрон и шумовые отголоски |
| dark_impact | make_rune_audio.py / dark / seed 631 | Codex для ShizoBox | CC0-1.0 | затягивающая пустота и низкий резонанс |
| sludge_activate | make_rune_audio.py / sludge / seed 640 | Codex для ShizoBox | CC0-1.0 | пузыри, влажные хлопки, вязкий шум |
| sludge_impact | make_rune_audio.py / sludge / seed 641 | Codex для ShizoBox | CC0-1.0 | короткий органический всплеск |

Рык и шёпот — синтетические тембры, не записи голоса; лёд и болото —
звуковой дизайн, не полевые записи. Это выбранная альтернатива внешним библиотекам.
NumPy и FFmpeg используются как инструменты синтеза/кодирования, их код в пак не входит.
Формат: PCM16 WAV и mono 44100 Hz Vorbis OGG. Измерения и SHA-256:
[verification.json](audio-v1/verification.json). Реальная проверка в Minecraft не проведена.
