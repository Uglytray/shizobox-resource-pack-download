# New rune audio — provenance recorded before synthesis (2026-09-16)

Eight new sounds: spark, leech, growth, chaos × activate/impact.
Sources: mathematically generated oscillators, envelopes and deterministic PRNG
noise only. No downloaded recordings, Minecraft samples, music or third-party
sound libraries are used. The generator and its new WAV/OGG output are dedicated
to the public domain under CC0-1.0: https://creativecommons.org/publicdomain/zero/1.0/ .
There are no external input recordings whose license must be verified.

Pipeline reuses the project's original CC0 generator in
`development/rune-audio-work/make_rune_audio.py`; NumPy and FFmpeg/libvorbis are
tools, not sampled source material. `audio-v2/verification.json` records seeds,
hashes, decoded durations, loudness and true peak for each generated file.

Sound concepts: spark = staccato electrical chirps; leech = inward pitch sweeps
and paired heartbeat; growth = progressively denser rising sprouts; chaos =
deterministic irregular bitcrushed pulses. Activation and impact are distinct.

The four existing CC0 rune themes remain byte-identical: ice crystals fit the
closing ice clamp; infernal crackling fits progressive burn; a dark drone fits
the delayed cut; bubbling fits corruption trails. Existing Warden/glitch assets
are preserved and retain their separately documented, unverified source license.
This dedication applies only to the new original audio and generator additions.
