"""Original sample-free rune synthesis. Generator and new output: CC0-1.0."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import wave
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'boss-audio-work/python-deps'))
import imageio_ffmpeg

FF = imageio_ffmpeg.get_ffmpeg_exe()
SR = 44100
OUT = ROOT / 'audio-v2'


def ff(args, data=None):
    return subprocess.run([FF, '-hide_banner', '-loglevel', 'error', *args],
                          input=data, capture_output=True, check=True).stdout


def filt(x, spec):
    return np.frombuffer(ff(['-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', 'pipe:0',
        '-af', spec, '-ar', str(SR), '-f', 'f32le', 'pipe:1'],
        x.astype('<f4').tobytes()), dtype='<f4').astype(float)


def tone(freq):
    return np.sin(2 * np.pi * np.cumsum(freq) / SR)


def add(x, at, fragment):
    start = int(at * SR)
    n = min(len(fragment), len(x) - start)
    if n > 0:
        x[start:start+n] += fragment[:n]


def synth(rune, impact, seed):
    rng = np.random.default_rng(seed)
    duration = (1.45 if impact else 2.65) + (.4 if rune == 'dark' else 0)
    t = np.arange(round(SR * duration)) / SR
    noise = rng.normal(0, 1, len(t))
    env = (1 - np.exp(-t / (.012 if impact else .045))) * np.exp(-t / (duration * .27))
    x = np.zeros_like(t)
    if rune == 'spark':
        for i in range(7 if impact else 12):
            at = i * (.055 if impact else .12)
            u = np.arange(int(SR*.16))/SR
            chirp = tone(2200*np.exp(-u/.025)+180) * np.exp(-u/.04)
            chirp += .24*rng.normal(0,1,len(u))*np.exp(-u/.012)
            add(x,at,chirp*.35)
    elif rune == 'leech':
        for at in [.03,.2,.62,.8]:
            u=np.arange(int(SR*.45))/SR
            add(x,at,.5*tone(110-50*np.minimum(u/.45,1))*np.exp(-u/.08)*(1-np.exp(-u/.004)))
        x += .22*tone(950*np.exp(-t/.5)+65)*env
        x += .08*filt(noise,'lowpass=f=1200,highpass=f=200')*env
    elif rune == 'growth':
        for i in range(14 if impact else 22):
            at=duration*.75*(i/22)**.65
            u=np.arange(int(SR*.28))/SR
            f=140+i*37
            add(x,at,.2*tone(f+180*u)*np.sin(np.pi*np.minimum(u/.28,1))**2)
        x += .1*filt(noise,'lowpass=f=700')*env
    elif rune == 'chaos':
        for i in range(22 if impact else 35):
            at=rng.uniform(0,duration*.8)
            u=np.arange(int(SR*rng.uniform(.025,.10)))/SR
            pulse=np.round(3*tone(np.full(len(u),rng.choice([133,277,619,1409]))))/3
            pulse*=np.sin(np.pi*np.arange(len(u))/len(u))**2
            add(x,at,pulse*.24)
        x += .1*tone(65+35*np.sin(t*31))*env
    elif rune == 'winter':
        wind = filt(noise, 'highpass=f=1200,lowpass=f=8500')
        x += .24 * wind * env * (.7 + .3 * np.sin(2*np.pi*2.3*t))
        for i in range(19 if impact else 30):
            at = rng.uniform(0, duration * .58)
            u = np.arange(int(SR * .65)) / SR
            f = rng.uniform(1500, 5700)
            crystal = sum(np.sin(2*np.pi*f*ratio*u+rng.uniform(0,6.28))
                          * np.exp(-u*(8+j*6)) / (j+1)
                          for j, ratio in enumerate([1, 1.479, 2.091]))
            crystal *= (1-np.exp(-u/.001)) * rng.uniform(.08,.19) * np.exp(-at)
            add(x, at, crystal)
        x += .16 * filt(noise, 'highpass=f=2500') * np.exp(-t/0.025)
    elif rune == 'demon':
        fundamental = 61 + 72*np.exp(-t/.24) + 3*np.sin(2*np.pi*17*t)
        phase = 2*np.pi*np.cumsum(fundamental)/SR
        voice = sum(np.sin(k*phase + .3*np.sin(2*np.pi*29*t)) / k**.85
                    for k in range(1, 22))
        voice = filt(voice, 'highpass=f=65,lowpass=f=2600,equalizer=f=470:t=q:w=1:g=7,equalizer=f=1050:t=q:w=1:g=4')
        x += .45 * np.tanh(voice*1.5) * env * (.8+.2*np.sin(2*np.pi*23*t))
        x += .24 * filt(noise, 'lowpass=f=1700,highpass=f=100') * env
        x += .32 * tone(42+28*np.exp(-t/.1)) * np.exp(-t/.38) * (1-np.exp(-t/.008))
        for at in rng.uniform(.02, duration*.55, 18):
            u = np.arange(int(.09*SR))/SR
            add(x, at, rng.normal(0,.1,len(u))*np.exp(-u/.014))
    elif rune == 'dark':
        for f, gain in [(46,.24),(69.4,.19),(94.1,.12),(142.7,.07)]:
            x += gain*tone(f + 1.6*np.sin(2*np.pi*.37*t))*env
        whisper = filt(noise, 'highpass=f=650,lowpass=f=2300')
        x += .26*whisper*env*(.5+.5*np.sin(2*np.pi*(1.7*t+.6*t*t)))**3
        x += .09*tone(410*np.exp(-t/1.2)+85)*env
    else:
        x += .15*filt(noise, 'lowpass=f=650,highpass=f=70')*env
        for at in sorted(rng.uniform(0, duration*.68, 22 if impact else 36)):
            length = rng.uniform(.06,.24)
            u = np.arange(int(length*SR))/SR
            f = rng.uniform(100,430)
            bubble = tone(f*(.55+1.1*np.exp(-u/.024)))
            bubble += .3*rng.normal(0,1,len(u))
            bubble *= np.sin(np.pi*np.minimum(u/length,1))**2*np.exp(-u/.065)
            add(x, at, bubble*rng.uniform(.3,.65)*np.exp(-at*.8))
        x += .15*tone(78+75*np.exp(-t/.08))*env
    # Delayed reflections are baked in; no vanilla echo events or extra tasks.
    dry = x.copy()
    for delay, gain in ([(.17,.25),(.37,.18),(.61,.1)] if rune=='dark'
                        else [(.071,.16),(.137,.08)]):
        add(x, delay, dry*gain)
    x = filt(x, 'highpass=f=35,lowpass=f=11000')
    n = int(.012*SR)
    x[:n] *= np.linspace(0,1,n)
    n = int(.18*SR)
    x[-n:] *= np.linspace(1,0,n)**2
    x = filt(x, 'loudnorm=I=-20:TP=-4:LRA=8')
    x *= min(1, .60/max(np.max(np.abs(x)),1e-9))
    return x


def main():
    assert (ROOT/'SOURCES.md').exists(), 'Record provenance before generating'
    OUT.mkdir(exist_ok=True)
    reports=[]
    for i, rune in enumerate(['spark','leech','growth','chaos']):
        for impact in [False, True]:
            name = rune + ('_impact' if impact else '_activate')
            seed = 610+i*10+int(impact)
            x = synth(rune, impact, seed)
            assert np.isfinite(x).all() and np.max(np.abs(x)) < .9
            wav, ogg = OUT/(name+'.wav'), OUT/(name+'.ogg')
            with wave.open(str(wav),'wb') as w:
                w.setparams((1,2,SR,0,'NONE','not compressed'))
                w.writeframes((x*32767).astype('<i2').tobytes())
            ff(['-y','-i',str(wav),'-map_metadata','-1','-ac','1','-ar',str(SR),
                '-c:a','libvorbis','-q:a','6',str(ogg)])
            decoded=np.frombuffer(ff(['-i',str(ogg),'-ac','1','-ar',str(SR),'-f','f32le','pipe:1']),dtype='<f4')
            assert np.isfinite(decoded).all() and np.max(np.abs(decoded)) < .9
            assert abs(len(decoded)-len(x)) < .02*SR and 1 < len(decoded)/SR < 4
            log=subprocess.run([FF,'-hide_banner','-i',str(ogg),'-af',
                'loudnorm=I=-20:TP=-4:LRA=8:print_format=json','-f','null','-'],capture_output=True,check=True).stderr.decode()
            metrics=json.loads(log[log.rfind('{'):log.rfind('}')+1])
            assert float(metrics['input_tp']) <= -3
            assert '44100 Hz, mono' in log and 'vorbis' in log
            reports.append(dict(file=name,seed=seed,channels=1,sample_rate=SR,duration_s=len(decoded)/SR,
                true_peak_dbtp=float(metrics['input_tp']),lufs=float(metrics['input_i']),
                sha256={p.suffix[1:]:hashlib.sha256(p.read_bytes()).hexdigest() for p in [wav,ogg]}))
    (OUT/'verification.json').write_text(json.dumps(reports,indent=2)+'\n')
    print(json.dumps(reports,indent=2))


if __name__=='__main__':
    main()
